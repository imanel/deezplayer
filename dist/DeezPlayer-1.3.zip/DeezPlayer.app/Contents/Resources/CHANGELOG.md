## Changelog

### v1.3

- New: Rename project to DeezPlayer
- New: New dock icon
- New: Less cluttered menu
- Fix: Deactivate application after closing window
- Fix: Allow cmd-tab back to application after closing window

### v1.2

- New: DeezPlayer will autoupdate from now on

### v1.1

- Fix: Scrolling some UI elements should not longer create glitches
- Fix: Prevent pausing music when closing window
