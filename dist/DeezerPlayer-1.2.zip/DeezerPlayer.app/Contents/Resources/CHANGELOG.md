## Changelog

### v1.2

- DeezerPlayer will autoupdate from now on

### v1.1

- Fix issue with scrolling some UI elements
- Prevent pausing music when closing window

### v1.0

- Initial release