if (typeof live === 'object' && typeof live.hideLiveBar === 'function') live.hideLiveBar();
$('html').addClass('unhide');
